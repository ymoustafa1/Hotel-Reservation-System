package app.controllers;

import app.SceneManager;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class AuthController {

    @FXML
    private TextField loginEmailField;

    @FXML
    private PasswordField loginPasswordField;

    @FXML
    private TextField visiblePasswordField;

    @FXML
    private Button togglePasswordButton;

    private boolean passwordVisible = false;

    @FXML
    public void handleLogin() {

        SceneManager.switchScene("/FXML/dashboard.fxml");
    }

    @FXML
    public void handleRegister() {

        SceneManager.switchScene("/FXML/dashboard.fxml");
    }

    @FXML
    public void togglePasswordVisibility() {

        if (passwordVisible) {

            loginPasswordField.setText(
                    visiblePasswordField.getText()
            );

            loginPasswordField.setVisible(true);
            loginPasswordField.setManaged(true);

            visiblePasswordField.setVisible(false);
            visiblePasswordField.setManaged(false);

            togglePasswordButton.setText("👁");

            passwordVisible = false;
        }

        else {

            visiblePasswordField.setText(
                    loginPasswordField.getText()
            );

            visiblePasswordField.setVisible(true);
            visiblePasswordField.setManaged(true);

            loginPasswordField.setVisible(false);
            loginPasswordField.setManaged(false);

            togglePasswordButton.setText("✖");

            passwordVisible = true;
        }
    }
}